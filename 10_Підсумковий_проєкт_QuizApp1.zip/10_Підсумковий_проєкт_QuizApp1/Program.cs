using System;
using System.IO;

namespace QuizApp
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.OutputEncoding = System.Text.Encoding.UTF8;

            Quiz quiz = new Quiz();
            SeedQuestions(quiz); //Завантажуємо нові питання

            while (true)
            {
                Console.WriteLine();
                Console.WriteLine("===ВІКТОРИНА: МИСТЕЦТВО ТА КОЛЬОРИ===");
                Console.WriteLine($"Усього питань у базі: {quiz.Questions.Count}");
                Console.WriteLine();
                Console.WriteLine("1. Почати тест (усі категорії)");
                Console.WriteLine("2. Почати тест (обрати категорію)");
                Console.WriteLine("3. Показати усі питання");
                Console.WriteLine("4. Додати своє питання");
                Console.WriteLine("5. Подивитись історію результатів");
                Console.WriteLine("0. Вихід");
                Console.Write("Виберіть пункт: ");

                string choice = Console.ReadLine()?.Trim() ?? "";

                switch (choice)
                {
                    case "0":
                        return;
                    case "1":
                        quiz.Start(null);
                        break;
                    case "2":
                        StartByCategory(quiz);
                        break;
                    case "3":
                        quiz.ShowAll();
                        break;
                    case "4":
                        AddCustomQuestion(quiz);
                        break;
                    case "5":
                        ShowHistory();
                        break;
                    default:
                        Console.WriteLine("Неправильний вибір!");
                        break;
                }

                Console.WriteLine("\nНатисніть будь-яку клавішу для продовження...");
                Console.ReadKey();
                Console.Clear();
            }
        }

        static void SeedQuestions(Quiz quiz)
        {
            //Група 1:Історія мистецтва
            quiz.AddQuestion(new Question(
                "У якому відомому музеї світу зберігається оригінал картини Леонардо да Вінчі «Мона Ліза»?",
                new string[] { "Лувр (Париж)", "Прадо (Мадрид)", "Метрополітен-музей (Нью-Йорк)", "Британський музей" },
                0,
                "Історія мистецтва"
            ));

            quiz.AddQuestion(new Question(
                "Хто є автором знаменитої мармурової скульптури «Давид»?",
                new string[] { "Донателло", "Леонардо да Вінчі", "Мікеланджело", "Рафаель" },
                2,
                "Історія мистецтва"
            ));

            //Група 2:Кольорознавство
            quiz.AddQuestion(new Question(
                "Який колір в українській мові традиційно називають брунатним?",
                new string[] { "Темно-синій", "Коричневий", "Яскраво-червоний", "Фіолетовий" },
                1,
                "Кольорознавство"
            ));

            quiz.AddQuestion(new Question(
                "Якщо вам запропонують річ блаватного кольору, якого відтінку вона буде?",
                new string[] { "Волошкового або ніжно-блакитного", "Золотисто-жовтого", "Пурпурового", "Світло-зеленого" },
                0,
                "Кольорознавство"
            ));

            quiz.AddQuestion(new Question(
                "Як виглядає жаристий колір?",
                new string[] { "Як колір нічного неба (темно-синій)", "Як колір стиглої трави (тьмяно-зелений)", "Як колір розжареного вугілля (оранжево-червоний)", "Як білий сніг" },
                2,
                "Кольорознавство"
            ));

            //Група 3:Стилі мистецтва
            quiz.AddQuestion(new Question(
                "Який стиль мистецтва надихався ідеалами античності, прагнув до суворої гармонії, симетрії та порядку?",
                new string[] { "Бароко", "Класицизм", "Імпресіонізм", "Готика" },
                1,
                "Стилі мистецтва"
            ));

            quiz.AddQuestion(new Question(
                "Назва якого стилю перекладається з португальської як «перлина химерної форми», а стиль вирізняється пишністю та динамізмом?",
                new string[] { "Бароко", "Романтизм", "Модерн", "Кубізм" },
                0,
                "Стилі мистецтва"
            ));

            quiz.AddQuestion(new Question(
                "Який стиль XVIII століття обожнював мотиви мушель, пастельні тони, легкість та прикрашав палаци аристократії?",
                new string[] { "Готика", "Рококо", "Реалізм", "Класицизм" },
                1,
                "Стилі мистецтва"
            ));
        }

        static void StartByCategory(Quiz quiz)
        {
            Console.WriteLine("\nДоступні категорії:");
            Console.WriteLine("- Історія мистецтва");
            Console.WriteLine("- Кольорознавство");
            Console.WriteLine("- Стилі мистецтва");
            Console.Write("Введіть назву категорії точно як у списку: ");
            
            string cat = Console.ReadLine()?.Trim() ?? "";
            quiz.Start(cat);
        }

        static void AddCustomQuestion(Quiz quiz)
        {
            Console.Write("Введіть текст питання: ");
            string text = Console.ReadLine() ?? "";

            string[] options = new string[4];
            for (int i = 0; i < 4; i++)
            {
                Console.Write($"Варіант {i + 1}: ");
                options[i] = Console.ReadLine() ?? "";
            }

            Console.Write("Номер правильної відповіді (1-4): ");
            if (int.TryParse(Console.ReadLine(), out int correctNum) && correctNum >= 1 && correctNum <= 4)
            {
                Console.Write("Введіть назву категорії для цього питання: ");
                string category = Console.ReadLine()?.Trim() ?? "Загальна";

                quiz.AddQuestion(new Question(text, options, correctNum - 1, category));
                Console.WriteLine("Питання успішно додано до бази!");
            }
            else
            {
                Console.WriteLine("Невірний номер!");
            }
        }

        static void ShowHistory()
        {
            Console.WriteLine("\n=== ІСТОРІЯ РЕЗУЛЬТАТІВ ===");
            if (File.Exists("results.txt"))
            {
                string[] history = File.ReadAllLines("results.txt");
                foreach (var line in history)
                {
                    Console.WriteLine(line);
                }
            }
            else
            {
                Console.WriteLine("Історія результатів ще порожня.");
            }
        }
    }
}