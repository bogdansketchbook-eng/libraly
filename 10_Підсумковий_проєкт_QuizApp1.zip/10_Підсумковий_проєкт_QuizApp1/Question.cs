using System;

namespace QuizApp
{
    internal class Question
    {
        public string Text { get; set; } = "";
        public string[] Options { get; set; } = new string[4];
        public int CorrectIndex { get; set; }
        public string Category { get; set; } = "Загальна";

        public Question(string text, string[] options, int correct, string category)
        {
            Text = text;
            Options = options;
            CorrectIndex = correct;
            Category = category;
        }

        public bool Ask()
        {
            Console.WriteLine();
            Console.WriteLine($"[{Category}] {Text}");
            
            for (int i = 0; i < Options.Length; i++)
            {
                Console.WriteLine($"{i + 1}. {Options[i]}");
            }
            
            Console.Write($"Ваш варіант (1-{Options.Length}): ");

            if (int.TryParse(Console.ReadLine(), out int answer))
            {
                bool isCorrectAnswer = (answer - 1) == CorrectIndex;
                
                if (isCorrectAnswer)
                {
                    Console.WriteLine("Відповідь правильна!");
                    return true;
                }
                else
                {
                    Console.WriteLine($"Відповідь неправильна. Правильний варіант: {Options[CorrectIndex]}");
                    return false;
                }
            }

            Console.WriteLine("Неправильний ввід!");
            return false;
        }
    }
}