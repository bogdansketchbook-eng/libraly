using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;

namespace QuizApp
{
    class Quiz
    {
        public List<Question> Questions { get; } = new();

        public void AddQuestion(Question question)
        {
            Questions.Add(question);
        }

        public void ShowAll()
        {
            Console.WriteLine("\n===Усі питання===");
            for (int i = 0; i < Questions.Count; i++)
            {
                var q = Questions[i];
                Console.WriteLine($"{i + 1}. [{q.Category}] {q.Text}");
            }
        }

        public void Start(string? category)
        {
            var subset = string.IsNullOrEmpty(category)
                ? Questions
                : Questions.Where(q => q.Category.Equals(category, StringComparison.OrdinalIgnoreCase)).ToList();

            if (subset.Count == 0)
            {
                Console.WriteLine("Запитань у цій категорії немає!");
                return;
            }

            int correct = 0;
            var start = DateTime.Now; //Таймер

            foreach (Question question in subset)
            {
                if (question.Ask())
                {
                    correct++;
                }
            }

            var duration = DateTime.Now - start;
            double score = (double)correct / subset.Count * 100;

            Console.WriteLine();
            Console.WriteLine("========================================");
            Console.WriteLine($" Результат: {correct} з {subset.Count} ({score:F0}%)");
            Console.WriteLine($" Час: {duration.TotalSeconds:F0} сек");

            string verdict = score switch
            {
                >= 90 => "Відмінно!",
                >= 75 => "Добре!",
                >= 60 => "Задовільно!",
                _ => "Спробуй ще раз!"
            };

            Console.WriteLine($" Оцінка: {verdict}");
            Console.WriteLine("========================================");

            //Тут збереження результату у файл results.txt
            string line = $"{DateTime.Now:yyyy-MM-dd HH:mm} Категорія: {category ?? "Усі"} | Бали: {correct}/{subset.Count} ({score:F0}%)";
            File.AppendAllText("results.txt", line + Environment.NewLine);
        }
    }
}